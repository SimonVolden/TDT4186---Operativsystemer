#pragma once
#include "utilities.h"
#include <time.h>
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

#define MAX_LIMIT 20
#define NUMBER_ALARMS 100

int main(void);